import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FeedbackFormComponent } from './feedbackform/feedbackform.component';


const routes: Routes = [
  { path: '',  redirectTo: '/feedbackform',  pathMatch: 'full'},
  { path: 'feedbackform', component: FeedbackFormComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
